<?php
declare(strict_types=1);

const SITE_ROOT = __DIR__ . '/..';
const PRIVATE_DIR = SITE_ROOT . '/private';
const CONTENT_FILE = PRIVATE_DIR . '/content.json';
const CONFIG_FILE = PRIVATE_DIR . '/config.php';

header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('Cache-Control: no-store');

function start_secure_session(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }
    session_name('shtrih_crm');
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
        'httponly' => true,
        'samesite' => 'Strict',
    ]);
    session_start();
}

function json_response(array $payload, int $status = 200): never
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function load_config(): array
{
    if (!is_file(CONFIG_FILE)) {
        json_response(['error' => 'CRM ещё не настроена'], 503);
    }
    $config = require CONFIG_FILE;
    if (!is_array($config) || empty($config['admin_username']) || empty($config['admin_password_hash'])) {
        json_response(['error' => 'Некорректная конфигурация CRM'], 503);
    }
    return $config;
}

function read_content(): array
{
    if (!is_file(CONTENT_FILE)) {
        json_response(['error' => 'Данные сайта ещё не загружены'], 503);
    }
    $handle = fopen(CONTENT_FILE, 'rb');
    if ($handle === false) {
        json_response(['error' => 'Не удалось прочитать данные сайта'], 500);
    }
    flock($handle, LOCK_SH);
    $json = stream_get_contents($handle);
    flock($handle, LOCK_UN);
    fclose($handle);
    $content = json_decode($json ?: '', true);
    if (!is_array($content)) {
        json_response(['error' => 'Данные сайта повреждены'], 500);
    }
    return $content;
}

function write_content(array $content): void
{
    if (!is_dir(PRIVATE_DIR) && !mkdir(PRIVATE_DIR, 0750, true) && !is_dir(PRIVATE_DIR)) {
        json_response(['error' => 'Не удалось создать хранилище'], 500);
    }
    $encoded = json_encode($content, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    if ($encoded === false) {
        json_response(['error' => 'Не удалось подготовить данные'], 422);
    }
    $temporary = tempnam(PRIVATE_DIR, 'content-');
    if ($temporary === false || file_put_contents($temporary, $encoded . "\n", LOCK_EX) === false) {
        json_response(['error' => 'Не удалось сохранить данные'], 500);
    }
    chmod($temporary, 0640);
    if (!rename($temporary, CONTENT_FILE)) {
        @unlink($temporary);
        json_response(['error' => 'Не удалось опубликовать изменения'], 500);
    }
}

function require_admin(): array
{
    start_secure_session();
    if (empty($_SESSION['crm_authenticated'])) {
        json_response(['error' => 'Требуется вход в CRM'], 401);
    }
    return load_config();
}

function require_same_origin(): void
{
    $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
    if ($origin === '') {
        return;
    }
    $originHost = parse_url($origin, PHP_URL_HOST);
    $requestHost = preg_replace('/:\d+$/', '', $_SERVER['HTTP_HOST'] ?? '');
    if (!is_string($originHost) || !hash_equals(strtolower($requestHost), strtolower($originHost))) {
        json_response(['error' => 'Запрос отклонён'], 403);
    }
}

function read_json_body(int $maximumBytes = 2097152): array
{
    $length = (int) ($_SERVER['CONTENT_LENGTH'] ?? 0);
    if ($length > $maximumBytes) {
        json_response(['error' => 'Слишком большой запрос'], 413);
    }
    $raw = file_get_contents('php://input', false, null, 0, $maximumBytes + 1);
    if (!is_string($raw) || strlen($raw) > $maximumBytes) {
        json_response(['error' => 'Слишком большой запрос'], 413);
    }
    $body = json_decode($raw, true);
    if (!is_array($body)) {
        json_response(['error' => 'Некорректный формат запроса'], 400);
    }
    return $body;
}

function validate_content(array $content): array
{
    foreach (['cities', 'services', 'cityPrices', 'extras', 'extraPrices', 'news', 'pages', 'pageButtons'] as $key) {
        if (!isset($content[$key]) || !is_array($content[$key])) {
            json_response(['error' => 'В данных отсутствует раздел ' . $key], 422);
        }
    }
    if (count($content['cities']) < 1 || !isset($content['contacts']) || !is_array($content['contacts'])) {
        json_response(['error' => 'Нужен хотя бы один город и контактные данные'], 422);
    }
    if (!isset($content['promotions']) || !is_array($content['promotions'])) {
        $content['promotions'] = [];
    }
    return $content;
}
